The classic method (manually copy the firmware file onto the SD card).
Firmware Upgrade(It would be better to upgrade when the battery is fully charged)
1. After downloading the firmware, unzip the downloaded file, find the RUNCAM5.BRN file and copy it to the root directory of the microSD card. 
The firmware name should be confirmed as RUNCAM5.BRN.
2. Disconnect from the computer, powering the camera via the mobile charger. 
And then turn on the camera with the micro SD card inserted. The camera will automatically update the firmware.
3. During the updating process, Blue light and Green light blink alternately.
4. After about 2-3 minute, the camera will automatically shut down, the upgrade has completed.

===========================================================================================

New Features of Firmware V1.2.2
1. Optimize image quality and reduce picture noise.


===========================================================================================

New Features of Firmware V1.2.1
1. Fixed some bugs.

===========================================================================================

New Features of Firmware V1.2.0
1. Adjust 1080P 60 video stream, the bitrate up to 45mbps.
2. Repair the automatic white balance occasional color temperature is cold.
3. The RunCam logo is turned off by default.
4. Fixed some bugs.

===========================================================================================
New Features of Firmware V1.1.5
1. Fixed some bugs.
